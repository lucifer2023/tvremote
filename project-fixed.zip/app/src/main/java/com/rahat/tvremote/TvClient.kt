package com.rahat.tvremote

import java.net.InetSocketAddress
import java.net.Socket
import java.security.MessageDigest
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import java.math.BigInteger
import java.io.InputStream
import java.io.OutputStream
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

object TvTls {
    fun connect(host: String, port: Int, identity: ClientIdentity): SSLSocket {
        // টিভির সার্টিফিকেট নিজে-সাইন করা, তাই যাচাই ছাড়াই মেনে নিচ্ছি (শুধু লোকাল নেটওয়ার্কে)
        val trustAll = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
        }
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(arrayOf(identity.keyManager()), arrayOf<TrustManager>(trustAll), null)
        val raw = Socket()
        raw.connect(InetSocketAddress(host, port), 8000)
        val s = ctx.socketFactory.createSocket(raw, host, port, true) as SSLSocket
        s.enabledProtocols = arrayOf("TLSv1.2")
        s.startHandshake()
        return s
    }
}

/** পেয়ারিং: টিভিতে দেখানো ৬ অক্ষরের কোড দিয়ে নিশ্চিত করা (পোর্ট 6467) */
class PairingSession(private val host: String, private val identity: ClientIdentity) {
    private var socket: SSLSocket? = null
    private lateinit var input: InputStream
    private lateinit var output: OutputStream
    private lateinit var serverCert: X509Certificate

    private fun outer(): PbWriter = PbWriter().int(1, 2).int(2, 200)

    private fun encoding(): PbWriter = PbWriter().int(1, 3).int(2, 6) // HEXADECIMAL, ৬ অক্ষর

    private fun send(w: PbWriter) = Frames.write(output, w.toByteArray())

    private fun expect(field: Int): PbMessage {
        val m = PbMessage.parse(Frames.read(input))
        val status = m.long(2)
        if (status != 200L) throw IllegalStateException("টিভি অনুরোধ নেয়নি (status $status)")
        if (!m.has(field)) throw IllegalStateException("টিভির অপ্রত্যাশিত উত্তর")
        return m
    }

    fun start() {
        val s = TvTls.connect(host, 6467, identity)
        socket = s
        input = s.inputStream
        output = s.outputStream
        serverCert = s.session.peerCertificates[0] as X509Certificate

        send(outer().msg(10, PbWriter().string(1, "atvremote").string(2, "Phone Remote")))
        expect(11)
        send(outer().msg(20, PbWriter().msg(1, encoding()).int(3, 1)))
        expect(20)
        send(outer().msg(30, PbWriter().msg(1, encoding()).int(2, 1)))
        expect(31)
    }

    private fun unsigned(n: BigInteger): ByteArray {
        val b = n.toByteArray()
        return if (b.size > 1 && b[0] == 0.toByte()) b.copyOfRange(1, b.size) else b
    }

    private fun hex(s: String): ByteArray =
        ByteArray(s.length / 2) { i -> s.substring(i * 2, i * 2 + 2).toInt(16).toByte() }

    fun finish(rawCode: String) {
        val code = rawCode.trim().uppercase()
        if (code.length != 6 || !code.all { it in "0123456789ABCDEF" }) {
            throw IllegalArgumentException("কোড ৬টি অক্ষরের হতে হবে (0-9, A-F)")
        }
        val codeBytes = hex(code)
        val ck = identity.certificate.publicKey as RSAPublicKey
        val sk = serverCert.publicKey as RSAPublicKey
        val md = MessageDigest.getInstance("SHA-256")
        md.update(unsigned(ck.modulus))
        md.update(unsigned(ck.publicExponent))
        md.update(unsigned(sk.modulus))
        md.update(unsigned(sk.publicExponent))
        md.update(codeBytes, 1, 2)
        val hash = md.digest()
        if (hash[0] != codeBytes[0]) throw IllegalStateException("কোড ভুল হয়েছে, আবার দেখুন")
        send(outer().msg(40, PbWriter().bytes(1, hash)))
        expect(41)
        close()
    }

    fun close() {
        try { socket?.close() } catch (_: Exception) {}
    }
}

/** রিমোট কানেকশন (পোর্ট 6466) */
class RemoteClient(
    private val host: String,
    private val identity: ClientIdentity,
    private val onConnected: (Boolean) -> Unit
) {
    @Volatile private var socket: SSLSocket? = null
    private val lock = Any()

    /** টিভির টেক্সট বক্স ফোকাসে থাকলে true (টিভি IME মেসেজ পাঠালে) */
    @Volatile var imeActive = false
    @Volatile private var imeCounter = 0L
    @Volatile private var fieldCounter = 0L
    /** শেষ কোন ধরনের মেসেজ এসেছে, ডিবাগের জন্য */
    @Volatile var lastInfo = ""

    /** টিভির সংযোগ ভাঙা পর্যন্ত চলে (ব্লকিং) */
    fun runLoop() {
        val s = TvTls.connect(host, 6466, identity)
        socket = s
        try {
            val input = s.inputStream
            while (true) {
                val m = PbMessage.parse(Frames.read(input))
                when {
                    m.has(1) -> send(
                        PbWriter().msg(
                            1,
                            PbWriter().int(1, 622).msg(
                                2,
                                PbWriter()
                                    .string(1, "Android")
                                    .string(2, "Google")
                                    .int(3, 1)
                                    .string(4, "1")
                                    .string(5, "com.rahat.tvremote")
                                    .string(6, "1.0.0")
                            )
                        )
                    )
                    m.has(2) -> {
                        send(PbWriter().msg(2, PbWriter().int(1, 622)))
                        onConnected(true)
                    }
                    m.has(8) -> {
                        val v = m.msg(8)?.long(1) ?: 0L
                        send(PbWriter().msg(9, PbWriter().int(1, v)))
                    }
                    m.has(20) -> {
                        // টিভির টেক্সট বক্স ফোকাস/পরিবর্তন
                        imeActive = true
                        val st = m.msg(20)?.msg(1)
                        if (st != null) fieldCounter = st.long(1, fieldCounter)
                        lastInfo = "ime20"
                    }
                    m.has(21) -> {
                        imeActive = true
                        val b = m.msg(21)
                        if (b != null) {
                            imeCounter = b.long(1, imeCounter)
                            fieldCounter = b.long(2, fieldCounter)
                        }
                        lastInfo = "ime21"
                    }
                    m.has(22) -> {
                        // টিভি কিবোর্ড দেখাতে বলেছে
                        imeActive = true
                        val st = m.msg(22)?.msg(2) ?: m.msg(22)?.msg(1)
                        if (st != null) fieldCounter = st.long(1, fieldCounter)
                        lastInfo = "ime22"
                    }
                    m.has(3) -> throw IllegalStateException("টিভি এরর পাঠিয়েছে")
                }
            }
        } finally {
            onConnected(false)
            close()
        }
    }

    private fun send(w: PbWriter) {
        synchronized(lock) {
            val s = socket ?: return
            Frames.write(s.outputStream, w.toByteArray())
        }
    }

    fun sendKey(code: Int) {
        // direction 3 = SHORT (একবার চাপ)
        send(PbWriter().msg(10, PbWriter().int(1, code).int(2, 3)))
    }

    /** টিভির টেক্সট বক্সে সরাসরি লেখা পাঠানো (বাংলাসহ যেকোনো লেখা) */
    fun sendText(text: String) {
        val status = PbWriter()
            .int(1, fieldCounter)
            .string(2, text)
            .int(3, text.length)
            .int(4, text.length)
        val edit = PbWriter().int(1, 1).msg(2, status)
        val batch = PbWriter()
            .int(1, imeCounter)
            .int(2, fieldCounter)
            .msg(3, edit)
        send(PbWriter().msg(21, batch))
    }

    fun launchApp(link: String) {
        send(PbWriter().msg(90, PbWriter().string(1, link)))
    }

    fun close() {
        try { socket?.close() } catch (_: Exception) {}
    }
}
