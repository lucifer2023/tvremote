package com.rahat.tvremote

import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    private val vm: RemoteViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) {
                    when (vm.screen) {
                        Screen.SETUP -> SetupScreen(vm)
                        Screen.CODE -> CodeScreen(vm)
                        Screen.REMOTE -> RemoteScreen(vm)
                    }
                }
            }
        }
    }

    // ফোনের ভলিউম বাটন দিয়ে টিভির ভলিউম
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (vm.screen == Screen.REMOTE) {
            when (keyCode) {
                KeyEvent.KEYCODE_VOLUME_UP -> { vm.key(24); return true }
                KeyEvent.KEYCODE_VOLUME_DOWN -> { vm.key(25); return true }
            }
        }
        return super.onKeyDown(keyCode, event)
    }
}

@Composable
fun SetupScreen(vm: RemoteViewModel) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("টিভি রিমোট", fontSize = 28.sp)
        Spacer(Modifier.height(8.dp))
        Text("ফোন ও টিভি একই Wi-Fi-তে থাকতে হবে। টিভির IP দেখতে: টিভির Settings → Network & Internet → আপনার Wi-Fi নামে চাপুন।")
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = vm.host,
            onValueChange = { vm.host = it },
            label = { Text("টিভির IP (যেমন 192.168.0.105)") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        Button(onClick = { vm.startPairing() }, enabled = !vm.busy, modifier = Modifier.fillMaxWidth()) {
            Text(if (vm.busy) "অপেক্ষা করুন…" else "পেয়ার করুন")
        }
        if (vm.status.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(vm.status)
        }
    }
}

@Composable
fun CodeScreen(vm: RemoteViewModel) {
    var code by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("কোড দিন", fontSize = 28.sp)
        Spacer(Modifier.height(8.dp))
        Text("টিভির স্ক্রিনে ৬ অক্ষরের একটা কোড এসেছে। সেটা এখানে লিখুন।")
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = code,
            onValueChange = { v -> code = v.filter { it.isLetterOrDigit() }.take(6).uppercase() },
            label = { Text("কোড") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = { vm.submitCode(code) },
            enabled = !vm.busy && code.length == 6,
            modifier = Modifier.fillMaxWidth()
        ) { Text("নিশ্চিত করুন") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { vm.cancelPairing() }, modifier = Modifier.fillMaxWidth()) {
            Text("বাতিল")
        }
        if (vm.status.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Text(vm.status)
        }
    }
}

@Composable
fun RBtn(label: String, big: Boolean = false, onClick: () -> Unit) {
    val view = LocalView.current
    FilledTonalButton(
        onClick = {
            view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            onClick()
        },
        modifier = Modifier.padding(4.dp).then(if (big) Modifier.size(84.dp) else Modifier.height(48.dp)),
        contentPadding = PaddingValues(horizontal = 12.dp)
    ) {
        Text(label, fontSize = if (big) 22.sp else 15.sp)
    }
}

@Composable
fun DPad(vm: RemoteViewModel) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        RBtn("▲", true) { vm.key(19) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            RBtn("◀", true) { vm.key(21) }
            RBtn("OK", true) { vm.key(23) }
            RBtn("▶", true) { vm.key(22) }
        }
        RBtn("▼", true) { vm.key(20) }
    }
}

@Composable
fun Touchpad(vm: RemoteViewModel) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(260.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .pointerInput(Unit) { detectTapGestures(onTap = { vm.key(23) }) }
            .pointerInput(Unit) {
                var ax = 0f
                var ay = 0f
                detectDragGestures(onDragStart = { ax = 0f; ay = 0f }) { change, amount ->
                    change.consume()
                    ax += amount.x
                    ay += amount.y
                    if (abs(ax) >= 70f || abs(ay) >= 70f) {
                        if (abs(ax) >= abs(ay)) vm.key(if (ax > 0) 22 else 21)
                        else vm.key(if (ay > 0) 20 else 19)
                        ax = 0f
                        ay = 0f
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text("সোয়াইপ করুন  •  ট্যাপ = OK")
    }
}

@Composable
fun RemoteScreen(vm: RemoteViewModel) {
    var touchpad by remember { mutableStateOf(false) }
    var showKeyboard by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                if (vm.connected) "● সংযুক্ত" else "○ " + vm.status.ifEmpty { "সংযোগ হচ্ছে…" },
                fontSize = 14.sp,
                modifier = Modifier.weight(1f)
            )
            Box {
                TextButton(onClick = { menuOpen = true }) { Text("⋮", fontSize = 20.sp) }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("নতুন করে পেয়ার করুন") },
                        onClick = { menuOpen = false; vm.unpair() }
                    )
                }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            RBtn("⏻ পাওয়ার") { vm.key(26) }
            RBtn("🔇 মিউট") { vm.key(164) }
            RBtn("⚙") { vm.key(176) }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("টাচপ্যাড মোড")
            Spacer(Modifier.size(8.dp))
            Switch(checked = touchpad, onCheckedChange = { touchpad = it })
        }

        if (touchpad) Touchpad(vm) else DPad(vm)

        Spacer(Modifier.height(8.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                RBtn("VOL +") { vm.key(24) }
                RBtn("VOL −") { vm.key(25) }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                RBtn("← ব্যাক") { vm.key(4) }
                RBtn("⌂ হোম") { vm.key(3) }
                RBtn("☰ মেনু") { vm.key(82) }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                RBtn("CH +") { vm.key(166) }
                RBtn("CH −") { vm.key(167) }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            RBtn("⏪") { vm.key(89) }
            RBtn("⏯") { vm.key(85) }
            RBtn("⏩") { vm.key(90) }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            RBtn("YouTube") { vm.openLink("https://www.youtube.com") }
            RBtn("Netflix") { vm.openLink("https://www.netflix.com") }
        }

        OutlinedButton(onClick = { showKeyboard = !showKeyboard }, modifier = Modifier.fillMaxWidth()) {
            Text(if (showKeyboard) "কিবোর্ড লুকান" else "⌨ টিভিতে টাইপ করুন")
        }

        if (showKeyboard) {
            var text by remember { mutableStateOf("") }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("টিভিতে যা লিখতে চান") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                RBtn("পাঠান") { vm.typeText(text); text = "" }
                RBtn("⌫") { vm.key(67) }
                RBtn("Enter") { vm.key(66) }
            }
        }
    }
}
