package com.rahat.tvremote

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.Executors

enum class Screen { SETUP, CODE, REMOTE }

class RemoteViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val identity by lazy { CertStore.load(app) }
    private val executor = Executors.newSingleThreadExecutor()
    private val sender = executor.asCoroutineDispatcher()

    var host by mutableStateOf(prefs.getString("host", "") ?: "")
    var screen by mutableStateOf(
        if (prefs.getBoolean("paired", false) && !prefs.getString("host", "").isNullOrBlank())
            Screen.REMOTE else Screen.SETUP
    )
    var status by mutableStateOf("")
    var busy by mutableStateOf(false)
    var connected by mutableStateOf(false)

    private var pairing: PairingSession? = null
    private var remote: RemoteClient? = null
    private var connectJob: Job? = null

    init {
        if (screen == Screen.REMOTE) connectRemote()
    }

    fun startPairing() {
        val h = host.trim()
        if (h.isEmpty()) { status = "টিভির IP লিখুন"; return }
        busy = true
        status = "টিভির সাথে যোগাযোগ হচ্ছে…"
        viewModelScope.launch(Dispatchers.IO) {
            try {
                pairing?.close()
                val p = PairingSession(h, identity)
                p.start()
                pairing = p
                prefs.edit().putString("host", h).apply()
                status = ""
                screen = Screen.CODE
            } catch (e: Exception) {
                status = "সংযোগ হয়নি: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                busy = false
            }
        }
    }

    fun submitCode(code: String) {
        val p = pairing ?: return
        busy = true
        status = "কোড যাচাই হচ্ছে…"
        viewModelScope.launch(Dispatchers.IO) {
            try {
                p.finish(code)
                pairing = null
                prefs.edit().putBoolean("paired", true).apply()
                status = ""
                screen = Screen.REMOTE
                connectRemote()
            } catch (e: Exception) {
                status = "পেয়ারিং হয়নি: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                busy = false
            }
        }
    }

    fun cancelPairing() {
        pairing?.close()
        pairing = null
        status = ""
        screen = Screen.SETUP
    }

    private fun connectRemote() {
        connectJob?.cancel()
        remote?.close()
        val h = host.trim()
        connectJob = viewModelScope.launch(Dispatchers.IO) {
            while (isActive) {
                try {
                    status = "সংযোগ হচ্ছে…"
                    val c = RemoteClient(h, identity) { connected = it }
                    remote = c
                    c.runLoop()
                } catch (e: Exception) {
                    status = "সংযোগ নেই (${e.message ?: e.javaClass.simpleName})"
                }
                connected = false
                delay(2500)
            }
        }
    }

    fun key(code: Int) {
        viewModelScope.launch(sender) {
            try { remote?.sendKey(code) } catch (_: Exception) {}
        }
    }

    fun openLink(link: String) {
        viewModelScope.launch(sender) {
            try { remote?.launchApp(link) } catch (_: Exception) {}
        }
    }

    fun typeText(text: String) {
        viewModelScope.launch(sender) {
            val c = remote
            // টিভির টেক্সট বক্স ফোকাসে থাকলে সরাসরি লেখা পাঠাই
            if (c != null && c.imeActive) {
                try {
                    c.sendText(text)
                    status = "লেখা পাঠানো হয়েছে (ime)"
                    return@launch
                } catch (_: Exception) {}
            }
            status = if (c?.imeActive == true) "" else "টিভির টেক্সট বক্স খোলেনি, বাটন-কী দিয়ে পাঠানো হচ্ছে"
            for (ch in text) {
                val k = charToKey(ch) ?: continue
                try { remote?.sendKey(k) } catch (_: Exception) {}
                delay(40)
            }
        }
    }

    private fun charToKey(c: Char): Int? = when (c) {
        in 'a'..'z' -> 29 + (c - 'a')
        in 'A'..'Z' -> 29 + (c - 'A')
        in '0'..'9' -> 7 + (c - '0')
        ' ' -> 62
        '.' -> 56
        ',' -> 55
        '-' -> 69
        '/' -> 76
        '@' -> 77
        else -> null
    }

    fun unpair() {
        connectJob?.cancel()
        remote?.close()
        remote = null
        prefs.edit().clear().apply()
        connected = false
        status = ""
        screen = Screen.SETUP
    }

    override fun onCleared() {
        connectJob?.cancel()
        remote?.close()
        pairing?.close()
        executor.shutdown()
        super.onCleared()
    }
}
