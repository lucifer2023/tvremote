package com.rahat.tvremote

import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.InputStream
import java.io.OutputStream

/** ছোট protobuf লেখার সরঞ্জাম (বাইরের লাইব্রেরি লাগে না) */
class PbWriter {
    private val out = ByteArrayOutputStream()

    private fun varint(v: Long) {
        var x = v
        while ((x and 0x7FL.inv()) != 0L) {
            out.write(((x and 0x7F) or 0x80).toInt())
            x = x ushr 7
        }
        out.write(x.toInt())
    }

    fun int(field: Int, v: Long): PbWriter {
        varint((field shl 3).toLong()); varint(v); return this
    }

    fun int(field: Int, v: Int): PbWriter = int(field, v.toLong())

    fun bytes(field: Int, b: ByteArray): PbWriter {
        varint(((field shl 3) or 2).toLong()); varint(b.size.toLong()); out.write(b); return this
    }

    fun string(field: Int, s: String): PbWriter = bytes(field, s.toByteArray(Charsets.UTF_8))

    fun msg(field: Int, w: PbWriter): PbWriter = bytes(field, w.toByteArray())

    fun toByteArray(): ByteArray = out.toByteArray()
}

class PbMessage(private val fields: Map<Int, List<Any>>) {
    fun has(f: Int): Boolean = fields.containsKey(f)
    fun long(f: Int, default: Long = 0L): Long = (fields[f]?.firstOrNull() as? Long) ?: default
    fun bytes(f: Int): ByteArray? = fields[f]?.firstOrNull() as? ByteArray
    fun msg(f: Int): PbMessage? = bytes(f)?.let { parse(it) }

    companion object {
        fun parse(data: ByteArray): PbMessage {
            val map = HashMap<Int, MutableList<Any>>()
            var i = 0

            fun varint(): Long {
                var shift = 0
                var r = 0L
                while (true) {
                    val b = data[i++].toInt() and 0xFF
                    r = r or ((b and 0x7F).toLong() shl shift)
                    if ((b and 0x80) == 0) return r
                    shift += 7
                }
            }

            while (i < data.size) {
                val tag = varint().toInt()
                val field = tag ushr 3
                when (tag and 7) {
                    0 -> map.getOrPut(field) { mutableListOf() }.add(varint())
                    1 -> i += 8
                    2 -> {
                        val len = varint().toInt()
                        map.getOrPut(field) { mutableListOf() }.add(data.copyOfRange(i, i + len))
                        i += len
                    }
                    5 -> i += 4
                    else -> throw IllegalArgumentException("অজানা protobuf ডেটা")
                }
            }
            return PbMessage(map)
        }
    }
}

/** দৈর্ঘ্য-প্রিফিক্স করা মেসেজ পড়া/লেখা */
object Frames {
    fun write(out: OutputStream, payload: ByteArray) {
        val buf = ByteArrayOutputStream()
        var n = payload.size
        while ((n and 0x7F.inv()) != 0) {
            buf.write((n and 0x7F) or 0x80)
            n = n ushr 7
        }
        buf.write(n)
        buf.write(payload)
        out.write(buf.toByteArray())
        out.flush()
    }

    fun read(inp: InputStream): ByteArray {
        var len = 0
        var shift = 0
        while (true) {
            val b = inp.read()
            if (b < 0) throw EOFException("টিভির সংযোগ বন্ধ হয়েছে")
            len = len or ((b and 0x7F) shl shift)
            if ((b and 0x80) == 0) break
            shift += 7
        }
        if (len < 0 || len > 1_000_000) throw EOFException("ভুল ডেটা")
        val buf = ByteArray(len)
        var off = 0
        while (off < len) {
            val r = inp.read(buf, off, len - off)
            if (r < 0) throw EOFException("টিভির সংযোগ বন্ধ হয়েছে")
            off += r
        }
        return buf
    }
}
